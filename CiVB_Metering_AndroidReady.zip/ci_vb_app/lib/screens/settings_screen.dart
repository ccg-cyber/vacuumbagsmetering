// lib/screens/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final darkMode = ref.watch(darkModeProvider);
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          // App info
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: cs.primaryContainer,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Icon(Icons.science, size: 40, color: cs.primary),
                ),
                const SizedBox(height: 10),
                Text('Vacuum Bags SARL',
                    style: theme.textTheme.titleLarge
                        ?.copyWith(fontWeight: FontWeight.w800)),
                Text('Ci™ Metering Support v2.1',
                    style: theme.textTheme.bodySmall
                        ?.copyWith(color: cs.outline)),
              ],
            ),
          ),
          const Divider(),
          SwitchListTile(
            title: const Text('Dark Mode'),
            subtitle: const Text('Switch between light and dark theme'),
            secondary: const Icon(Icons.dark_mode_outlined),
            value: darkMode,
            onChanged: (_) => ref.read(darkModeProvider.notifier).toggle(),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.restore),
            title: const Text('Reset to Defaults'),
            subtitle: const Text('Reload original material & cost data'),
            onTap: () => _confirmReset(context, ref),
          ),
          const Divider(),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Formula Reference', style: TextStyle(fontWeight: FontWeight.w700)),
                SizedBox(height: 8),
                _FormulaRow('Zipper / Slider Bag',
                    'WU = (L×2+G)×W×ΣK + 0.08×W'),
                _FormulaRow('Doypack Bag', 'WU = (L×2+G)×W×ΣK'),
                _FormulaRow('C.S. Bag', 'WU = ((W+G)×2+3)×L×ΣK'),
                _FormulaRow('Quattro Bag', 'WU = (W+G)×2×L×ΣK'),
                _FormulaRow('Side Seal Bag', 'WU = ((W+G)×2+1.5)×L×ΣK'),
                _FormulaRow('Label / Sleeve', 'WU = (W×2+1)×L×ΣK'),
                _FormulaRow('S.W. / T.S.S. Bag', 'WU = (L×2+G)×W×ΣK'),
                _FormulaRow('ROLL', 'Len = WeightKG×1000/(ΣK×Width×100)'),
                SizedBox(height: 6),
                Text(
                  'WU = Weight per Unit (gr), K = weight factor from Sheet2 col G\n'
                  'WEIGHT/KG = qty×(WU−bonus)/1000\n'
                  'METERS/KG = WEIGHT/KG×1000/(perimeter×ΣK×100)',
                  style: TextStyle(fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _confirmReset(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reset Data?'),
        content: const Text(
            'This will reload the original materials and costs from the built-in seed files. Custom entries will be lost.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.error),
            onPressed: () async {
              await ref.read(repositoryProvider).resetToDefaults();
              ref.read(materialsProvider.notifier).refresh();
              ref.read(costsProvider.notifier).refresh();
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text('Data reset!')));
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }
}

class _FormulaRow extends StatelessWidget {
  final String product;
  final String formula;
  const _FormulaRow(this.product, this.formula);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
                width: 120,
                child: Text(product,
                    style: const TextStyle(
                        fontSize: 11, fontWeight: FontWeight.w600))),
            Expanded(
              child: Text(formula,
                  style: TextStyle(
                      fontSize: 11,
                      color: Theme.of(context).colorScheme.primary,
                      fontFamily: 'monospace')),
            ),
          ],
        ),
      );
}
